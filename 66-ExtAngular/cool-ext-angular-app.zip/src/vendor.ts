// Angular
import '@angular/common';
import '@angular/core';
import '@angular/forms';
import '@angular/http';
import '@angular/router';

// RxJS
import 'rxjs';
